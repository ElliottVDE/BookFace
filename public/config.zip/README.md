# About The Project

BookFace is a prototype social media site being built for the purposes of learning and gaining experience for CMICH university students. 

## Installation

1. Clone the repo.
```sh
git clone https://github.com/ElliottVDE/BookFace.git
```

2. Open a console in the base project directory

3. use 'npm start'

4. run live server on public/index.html